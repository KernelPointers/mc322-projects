package pt.c40task.l05wumpus;
import java.util.ArrayList;

public class Room {
    private ArrayList<Components> items = new ArrayList();
    private char statusID;

    public Room(){
        
    }



}

