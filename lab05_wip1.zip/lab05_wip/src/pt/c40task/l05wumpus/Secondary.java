
public class Secondary extends Components{

    public Secondary(int i, int j, char id){
        this.i = i;
        this.j = j;
        this.id = id;
    }


}
