public class Smell extends Secondary {

    public Smell(int i, int j){
        this.i = i;
        this.j = j;
    } 
}
