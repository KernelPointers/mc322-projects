public class Wind extends Secondary {

    public Wind(int i, int j){
        this.i = i;
        this.j = j;
    } 

}

