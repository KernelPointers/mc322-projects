public class Wumpus extends Enemy {

    public Wumpus(int i, int j){
        this.i = i;
        this.j = j;

    }

    public void setSmell(){
        int dim = this.world.num;
        this.setSec();


    }

}
